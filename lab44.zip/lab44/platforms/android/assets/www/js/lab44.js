function sum(){
	console.log(3+4);
}